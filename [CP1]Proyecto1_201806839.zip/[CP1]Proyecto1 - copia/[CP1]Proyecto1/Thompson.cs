﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _CP1_Proyecto1
{
    public class Thompson
    {

        int cont;

        public Nodo AFN(Nodo arbol, int cont) {
            this.cont = cont;
            arbol=recorrerRecursivo(arbol);
            return arbol;
        }

        public Nodo copy(Nodo param)
        {
            Nodo temp = new Nodo(param);
            return temp;
        }
        Nodo recorrerRecursivo(Nodo param) {
            if (param != null) {

                Nodo tempIz = recorrerRecursivo(param.izquierda);
                if (tempIz != null) {
                    param.izquierda = tempIz;
                }

                Nodo tempDer = recorrerRecursivo(param.derecha);
                if (tempDer != null)
                {
                    param.derecha = tempDer;
                }

                if (param.tipoAux.Equals("operador"))
                {
                    if (param.info.Equals("."))
                    {   
                        param.transiciones = concatenacion(param.izquierda, param.derecha);
                    }
                    else if (param.info.Equals("+"))
                    {
                        Nodo temp = copy(param.izquierda);
                        foreach (var item in param.izquierda.transiciones)
                        {
                            LinkedList<Nodo> listaAux = new LinkedList<Nodo>();
                            foreach (var inside in item.transiciones)
                            {
                                Nodo auxPrim = copy(inside);
                                listaAux.AddLast(auxPrim);
                            }
                            Nodo auxSec = copy(item);
                            auxSec.transiciones = listaAux;
                            temp.transiciones.AddLast(auxSec);
                        }
                        metodoProhibido(temp);

                        param.transiciones = kleene(param.izquierda);

                        param.transiciones = concatenacion(temp, param);
                         
                    }
                    else if (param.info.Equals("|"))
                    {
                            param.transiciones= alternancia(param.izquierda, param.derecha);

                    }
                    else if (param.info.Equals("?"))
                    {
                        Nodo aux = new Nodo(cont); cont++;               
                        if (true)
                        {
                            LinkedList<Nodo> listaNodo = new LinkedList<Nodo>();
                            Nodo inicio = new Nodo(cont); cont++;
                            Nodo fin = new Nodo(cont); cont++; fin.info = "Ɛ";

                            inicio.transiciones.AddLast(fin);
                            listaNodo.AddLast(inicio);
                            listaNodo.AddLast(fin);

                            aux.transiciones = listaNodo;
                        }    
                        param.transiciones= alternancia(param.izquierda, aux);
                    }
                    else if (param.info.Equals("*"))
                    {
                            param.transiciones= kleene(param.izquierda);
                    }
                }
        
                return param;
            }
            return null;      
        }

        LinkedList<Nodo> concatenacion(Nodo r,Nodo t) {
            LinkedList<Nodo> listaNodo = new LinkedList<Nodo>();
                foreach (var item in t.transiciones.First().transiciones)
                {
                    r.transiciones.Last().transiciones.AddLast(item);
                }

                t.transiciones.RemoveFirst();
          
                foreach (var item in r.transiciones)
                {
                    listaNodo.AddLast(item);
                }
                foreach (var item in t.transiciones)
                {
                    listaNodo.AddLast(item);
                }

            return listaNodo;

           
        }
        LinkedList<Nodo> kleene(Nodo r) {
            LinkedList<Nodo> listaNodo = new LinkedList<Nodo>();
            Nodo inicio = new Nodo(cont); cont++;
            Nodo fin = new Nodo(cont); cont++; fin.info = "Ɛ";
            r.transiciones.First().info = "Ɛ";


            inicio.transiciones.AddLast(r.transiciones.First());
            inicio.transiciones.AddLast(fin);
            r.transiciones.Last().transiciones.AddLast(fin);
            r.transiciones.Last().transiciones.AddLast(r.transiciones.First());

            listaNodo.AddLast(inicio);
            foreach (var item in r.transiciones)
            {
                listaNodo.AddLast(item);
            }
            listaNodo.AddLast(fin);

            return listaNodo;
        }
        LinkedList<Nodo> alternancia(Nodo r, Nodo t) {
            
                LinkedList<Nodo> listaNodo = new LinkedList<Nodo>();
                Nodo inicio = new Nodo(cont); cont++;
                Nodo fin = new Nodo(cont); cont++; fin.info = "Ɛ";
                r.transiciones.First().info= "Ɛ";
                t.transiciones.First().info= "Ɛ";

                inicio.transiciones.AddLast(r.transiciones.First());
                inicio.transiciones.AddLast(t.transiciones.First());
                r.transiciones.Last().transiciones.AddLast(fin);
                t.transiciones.Last().transiciones.AddLast(fin);

                listaNodo.AddLast(inicio);
                foreach (var item in r.transiciones) 
            {
                listaNodo.AddLast(item);
            }
                foreach (var item in t.transiciones)
            {
                listaNodo.AddLast(item);
            }
                listaNodo.AddLast(fin);

            return listaNodo; 
            }

        void metodoProhibido(Nodo param) {
            
            int bandera = 0;
            foreach (var item in param.transiciones)
            {
   
                item.ID += cont;
                if (item.ID > bandera) {
                    bandera = item.ID;
                }
                foreach (var inside in item.transiciones)
                {
                    inside.ID += cont;
                    if (inside.ID > bandera)
                    {
                        bandera = item.ID;
                    }
                
                }
            }
            cont = bandera++;
  
        }


    }
}
