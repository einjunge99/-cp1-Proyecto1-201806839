﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _CP1_Proyecto1
{
    class Subconjuntos
    {
        int cont = 0;
        LinkedList<Estado> estados = new LinkedList<Estado>();

        LinkedList<Nodo> terminales;
        LinkedList<Nodo> transiciones;
        int i = 0;
        int k = 0;

        int mayor = 0;

        public LinkedList<Estado> AFD(LinkedList<Nodo> transiciones, LinkedList<Nodo> terminales)
        {
            this.terminales = terminales;
            this.transiciones = transiciones;
            mayor = transiciones.Last().ID;

            LinkedList<int> inicial = new LinkedList<int>();
            Nodo nodoInicial = new Nodo(0,"","");
            inicial.AddLast(transiciones.First().ID);
            eCerradura(inicial,nodoInicial);



            for (i = 0; i < estados.Count; i++)
            {
                Estado item = estados.ElementAt(i);

                if (!item.marcar)
                {

                    foreach (var inside in terminales)
                    {
                        LinkedList<int> temp = mov(item.elementos, inside.info);

                        if (temp.Count() != 0)
                        {

                            for (k = 0; k < estados.Count; k++)
                            {
                                Estado insiderisimo = estados.ElementAt(k);

                                if (!insiderisimo.marcar)
                                {
                                    Estado aux = null;
                                    foreach (var abr in estados)
                                    {
                                        if (abr.mov.All(temp.Contains) && temp.All(abr.mov.Contains))
                                        {
                                            aux = abr;
                                            break;
                                        }
                                    }
                                    if (aux != null)
                                    {
                                        Estado estado = new Estado(aux.ID, inside.info, temp);
                                        estado.tipo = inside.tipo;
                                        estado.fin = inside.fin;
                                        estado.transiciones = aux.transiciones;
                                        insiderisimo.transiciones.AddLast(estado);
                                        k = estados.Count();
                                    }
                                    else
                                    {
                                      
                                            insiderisimo.transiciones.AddLast(eCerradura(temp, inside));
                  
                                    }
                                }
                            }
                        }
                    }
                    item.marcar = true;
                }

            }

            return estados;
        }

      
        Nodo buscar(int ID)
        {
            foreach (var item in transiciones)
            {
                if (item.ID == ID)
                {
                    return item;
                }
            }
            return null;
        }
        Estado eCerradura(LinkedList<int> mov, Nodo terminal)
        {
            LinkedList<int> listaTemp = new LinkedList<int>();
            foreach (var item in mov)
            {
                listaTemp = cerraduraRecursiva(buscar(item), listaTemp);
            }

            foreach (var item in mov)
            {
                listaTemp.AddLast(item);
            }
  
            Estado estado = new Estado(cont, terminal.info, mov); cont++;
            estado.tipo = terminal.tipo;
            estado.fin = terminal.fin;
            estado.elementos = listaTemp;

            if (listaTemp.Contains(mayor)) {
                estado.fin = true;
            }

            estados.AddLast(estado);
            k = estados.Count();
            i = -1;
            return estado;
       
        }
        LinkedList<int> cerraduraRecursiva(Nodo nodo, LinkedList<int> param)
        {
            LinkedList<int> listaTemp = param;
            foreach (var item in nodo.transiciones)
            {
                if (item.info.Equals("Ɛ"))
                {
                    if (!listaTemp.Contains(item.ID))
                    {
                        listaTemp.AddLast(item.ID);
                        listaTemp = cerraduraRecursiva(buscar(item.ID), listaTemp);
                    }
                }
            }
            return listaTemp;
        }
        LinkedList<int> movRecursivo(Nodo nodo, string terminal, LinkedList<int> param)
        {
            LinkedList<int> listaTemp = param;
            foreach (var item in nodo.transiciones)
            {
                if (item.info.Equals(terminal))
                {
                    if (!listaTemp.Contains(item.ID))
                    {
                        listaTemp.AddLast(item.ID);
                        listaTemp = movRecursivo(buscar(item.ID), terminal, listaTemp);
                    }
                }
            }
            return listaTemp;
        }
        LinkedList<int> mov(LinkedList<int> conjunto, string terminal)
        {
            LinkedList<int> listaTemp = new LinkedList<int>();
            foreach (var item in conjunto)
            {
                listaTemp = movRecursivo(buscar(item), terminal, listaTemp);
            }
            return listaTemp;
        }

    }
}
