﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _CP1_Proyecto1
{
    public class Directorio
    {
        public string ruta;
        public string ventana;

        public Directorio(string ruta, string ventana)
        {
            this.ruta = ruta;
            this.ventana = ventana;

        }
    }
}
